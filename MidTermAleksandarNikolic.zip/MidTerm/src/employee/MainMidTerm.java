package employee;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;


public class MainMidTerm {
	
	private static ObjectFactory of;
    private EmployeeRequest request;
    private EmployeeResponse response;
    
    

	public MainMidTerm() {
		of = new ObjectFactory();
		request = of.createEmployeeRequest();
		response = of.createEmployeeResponse();
	}



	public static void main(String[] args) {
		MainMidTerm maiMidTerm = new MainMidTerm();
		
		// info for request
		Employees em = new Employees();
		em.setFirstName("");
		em.setLastName("Nikolic");
		em.setPhoneNumber("123456789");
		
		//info for response
		Employees em1 = new Employees();
		em1.setEmployeeID(10);
		em1.setFirstName("Miki");
		em1.setLastName("Mouse");
		em1.setEmail("bb@bbb.bb");
		em1.setPhoneNumber("45678");
    	GregorianCalendar cal = new GregorianCalendar();   	
    	try {
			XMLGregorianCalendar hireDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			em.setHireDate(hireDate);
    	} catch (DatatypeConfigurationException e1) {
			e1.printStackTrace();
    	}
    	em1.setCommiissionPCT("big");
    	em1.setSalary(45646);
    	
    	Jobs job = new Jobs();
    	job.setJobTitle("manager");
    	job.setMinSalary(15000);
    	job.setMaxSalary(150000);
    	
    	Departments dep = new Departments();
    	dep.setDepartmnetName("sport");
    	Employees emm = new Employees();
    	emm.setFirstName("Miki");
    	emm.setLastName("Mouse");  	
    	dep.setManagerID(emm);   	
    	Locations loc = new Locations();
    	loc.setStreetAddress("Bloor 55");   	
    	Countries country = new Countries();
    	country.setCountryName("Canada");    	
    	loc.setCountryID(country); 	
    	dep.setLocationID(loc);
    	em1.setJobID(job);
    	em1.setManagerID(dep);

		
		
		maiMidTerm.createEmployeeRequest(em);
		maiMidTerm.createEmployeeResponse(em1);
		maiMidTerm.marshal();
		
	}



	private void createEmployeeResponse(Employees em1) {
		response.getEmployees().add(em1);
		
	}



	private void marshal() {
		try {
			JAXBElement<EmployeeRequest> req = of.createEmployeeRequest(request);
			JAXBElement<EmployeeResponse> res = of.createEmployeeResponse(response);
			JAXBContext jc = JAXBContext.newInstance( "employee" );
			
			Marshaller m = jc.createMarshaller();
			
			m.marshal( req, System.out );
			m.marshal( res, System.out );
			
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



	private void createEmployeeRequest(Employees em) {
		if(!(em.getFirstName().equals(null))) {
    		request.setFirstName(em.getFirstName());
    	}
		if(!(em.getLastName().equals(null))) {
    		request.setLastName(em.getLastName());
    	}
    	if(!(em.getPhoneNumber().equals(null))) {
    		request.setPhoneNumber(em.getPhoneNumber());
    	}	
	}

}
