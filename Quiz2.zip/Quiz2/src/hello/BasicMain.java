package hello;

import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class BasicMain {

	private ObjectFactory of;
	private SearchStudentRequest ssr;
	private Student sr;

	public BasicMain() {

		of = new ObjectFactory();
		ssr = of.createSearchStudentRequest();
		sr = of.createStudent();

	}

	public static void main(String[] args) {

		BasicMain mm = new BasicMain();
		mm.makeRequest();
		mm.makeResponse();
		mm.marshalRequest();
		mm.marshalResponse();

	}

	private void marshalResponse() {

		try {
			JAXBElement<Student> gl = of.createResponse(sr);

			JAXBContext jc = JAXBContext.newInstance("hello");
			Marshaller m = jc.createMarshaller();
			m.marshal(gl, System.out);
		} catch (JAXBException jbe) {
			// ...
		}
	}

	private void makeResponse() {
		sr.setId(45);
		sr.setName("Aleksandar");
		sr.setStreet("Bloor");
		sr.setTown("Toronto");
		sr.setPhone(456789);
		sr.setEmail("bbb@bbb.bb");

		GregorianCalendar gcal = new GregorianCalendar();
		try {
			XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
			sr.setEnrollDate(xgcal);

		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Family fm = new Family();
		fm.setId(1);
		fm.setNameFamily("Nikolic");
		sr.setFamily(fm);

		Payment py = new Payment();
		py.setAmount(500);
		py.setId(1);
		sr.setPayment(py);

		Belt bl = new Belt();
		bl.setDescription("New Student at College");
		bl.setIsChild(true);
		sr.setBelt(bl);

	}

	private void marshalRequest() {
		try {
			JAXBElement<SearchStudentRequest> gl = of.createRequest(ssr);

			JAXBContext jc = JAXBContext.newInstance("hello");
			Marshaller m = jc.createMarshaller();
			m.marshal(gl, System.out);
		} catch (JAXBException jbe) {
			// ...
		}

	}

	private void makeRequest() {

		ssr.setName("Alex");
		ssr.setPhoneNumber("777-777-7777");

		GregorianCalendar gcal = new GregorianCalendar();
		GregorianCalendar gcal1 = new GregorianCalendar();
		try {
			XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
			XMLGregorianCalendar xgcal1 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal1);
			ssr.setEnrollDate(xgcal);
			ssr.setDropDate(xgcal1);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ssr.setEmailAddress("aaa@aaa.aa");

	}

}
